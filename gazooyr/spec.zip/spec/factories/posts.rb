FactoryGirl.define do
  factory :post do
    title "MyString"
    content "MyText"
  end
end
