require 'spec_helper'

describe Page do
  pending "add some examples to (or delete) #{__FILE__}"
end
