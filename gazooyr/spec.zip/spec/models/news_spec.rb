require 'spec_helper'

describe News do
  pending "add some examples to (or delete) #{__FILE__}"
end
